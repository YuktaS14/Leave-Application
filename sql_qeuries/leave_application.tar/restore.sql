--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE leave_application;
--
-- Name: leave_application; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE leave_application WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_IN' LC_CTYPE = 'en_IN';


ALTER DATABASE leave_application OWNER TO postgres;

\connect leave_application

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status AS ENUM (
    'pending',
    'approved',
    'rejected'
);


ALTER TYPE public.status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: faculty_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faculty_list (
    name character varying,
    email character varying NOT NULL
);


ALTER TABLE public.faculty_list OWNER TO postgres;

--
-- Name: holiday_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.holiday_list (
    holiday character varying,
    date timestamp without time zone,
    day character varying,
    type character varying
);


ALTER TABLE public.holiday_list OWNER TO postgres;

--
-- Name: leave_applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leave_applications (
    roll_no integer,
    name character varying,
    depeartment character varying,
    program character varying,
    leave_balance integer,
    leave_perpose character varying,
    days_applied integer,
    overflow_leave integer,
    type_of_leave integer,
    from_date timestamp without time zone,
    to_date timestamp without time zone,
    nature_of_duty character varying,
    alternate_student_roll_no character varying,
    alternate_student_name character varying,
    fa_status public.status DEFAULT 'pending'::public.status,
    pm_status public.status DEFAULT 'pending'::public.status,
    admin_status public.status DEFAULT 'pending'::public.status
);


ALTER TABLE public.leave_applications OWNER TO postgres;

--
-- Name: student_faculty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_faculty (
    roll_no integer,
    email_fa character varying,
    email_pm character varying
);


ALTER TABLE public.student_faculty OWNER TO postgres;

--
-- Name: student_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_info (
    roll_no integer NOT NULL,
    name character varying,
    leave_balance integer,
    extra_leave integer DEFAULT 0
);


ALTER TABLE public.student_info OWNER TO postgres;

--
-- Name: ta_instructor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ta_instructor (
    roll_no integer,
    instructor_email character varying,
    course character varying
);


ALTER TABLE public.ta_instructor OWNER TO postgres;

--
-- Data for Name: faculty_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faculty_list (name, email) FROM stdin;
\.
COPY public.faculty_list (name, email) FROM '$$PATH$$/2998.dat';

--
-- Data for Name: holiday_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.holiday_list (holiday, date, day, type) FROM stdin;
\.
COPY public.holiday_list (holiday, date, day, type) FROM '$$PATH$$/2996.dat';

--
-- Data for Name: leave_applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leave_applications (roll_no, name, depeartment, program, leave_balance, leave_perpose, days_applied, overflow_leave, type_of_leave, from_date, to_date, nature_of_duty, alternate_student_roll_no, alternate_student_name, fa_status, pm_status, admin_status) FROM stdin;
\.
COPY public.leave_applications (roll_no, name, depeartment, program, leave_balance, leave_perpose, days_applied, overflow_leave, type_of_leave, from_date, to_date, nature_of_duty, alternate_student_roll_no, alternate_student_name, fa_status, pm_status, admin_status) FROM '$$PATH$$/3001.dat';

--
-- Data for Name: student_faculty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_faculty (roll_no, email_fa, email_pm) FROM stdin;
\.
COPY public.student_faculty (roll_no, email_fa, email_pm) FROM '$$PATH$$/3000.dat';

--
-- Data for Name: student_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_info (roll_no, name, leave_balance, extra_leave) FROM stdin;
\.
COPY public.student_info (roll_no, name, leave_balance, extra_leave) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: ta_instructor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ta_instructor (roll_no, instructor_email, course) FROM stdin;
\.
COPY public.ta_instructor (roll_no, instructor_email, course) FROM '$$PATH$$/2997.dat';

--
-- Name: faculty_list faculty_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faculty_list
    ADD CONSTRAINT faculty_list_pkey PRIMARY KEY (email);


--
-- Name: student_info student_info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_info
    ADD CONSTRAINT student_info_pkey PRIMARY KEY (roll_no);


--
-- Name: student_faculty fk_email_fa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_faculty
    ADD CONSTRAINT fk_email_fa FOREIGN KEY (email_fa) REFERENCES public.faculty_list(email);


--
-- Name: student_faculty fk_email_pm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_faculty
    ADD CONSTRAINT fk_email_pm FOREIGN KEY (email_pm) REFERENCES public.faculty_list(email);


--
-- Name: student_faculty fk_roll_no; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_faculty
    ADD CONSTRAINT fk_roll_no FOREIGN KEY (roll_no) REFERENCES public.student_info(roll_no);


--
-- Name: ta_instructor fk_roll_no; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ta_instructor
    ADD CONSTRAINT fk_roll_no FOREIGN KEY (roll_no) REFERENCES public.student_info(roll_no);


--
-- Name: leave_applications fk_roll_no_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leave_applications
    ADD CONSTRAINT fk_roll_no_ FOREIGN KEY (roll_no) REFERENCES public.student_info(roll_no);


--
-- PostgreSQL database dump complete
--

