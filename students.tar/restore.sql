--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE students;
--
-- Name: students; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE students WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_IN' LC_CTYPE = 'en_IN';


ALTER DATABASE students OWNER TO postgres;

\connect students

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: approvalstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.approvalstatus AS ENUM (
    'Pending',
    'Approved',
    'Not Approved'
);


ALTER TYPE public.approvalstatus OWNER TO postgres;

--
-- Name: holidaytype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.holidaytype AS ENUM (
    'Gazetted',
    'Restricted'
);


ALTER TYPE public.holidaytype OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: faculty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faculty (
    name character varying(100),
    email character varying(100)
);


ALTER TABLE public.faculty OWNER TO postgres;

--
-- Name: holidays; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.holidays (
    holiday character varying(100) NOT NULL,
    date date NOT NULL,
    day character varying(100) NOT NULL,
    type public.holidaytype
);


ALTER TABLE public.holidays OWNER TO postgres;

--
-- Name: leaveapplications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leaveapplications (
    rollno integer NOT NULL,
    nameofscholar character varying(50) NOT NULL,
    department character varying(50),
    program character varying(50),
    leavesleft integer,
    typeofleave character varying(50),
    leavepurpose character varying(100),
    daysapplied integer,
    fromdate date,
    todate date,
    natureofduty character varying(50),
    alternatestudrolno integer,
    alternatestudname character varying(50),
    fa_approval public.approvalstatus DEFAULT 'Pending'::public.approvalstatus,
    mentor_approval public.approvalstatus DEFAULT 'Pending'::public.approvalstatus,
    admin_approval public.approvalstatus DEFAULT 'Pending'::public.approvalstatus,
    CONSTRAINT datecheck CHECK (((fromdate >= CURRENT_DATE) AND (todate >= CURRENT_DATE) AND (fromdate <= todate))),
    CONSTRAINT leavescheck CHECK ((daysapplied <= leavesleft))
);


ALTER TABLE public.leaveapplications OWNER TO postgres;

--
-- Name: studentfaculty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentfaculty (
    rollno integer NOT NULL,
    name character varying(50) NOT NULL,
    facultyadvisor character varying(50),
    projectmentor character varying(50)
);


ALTER TABLE public.studentfaculty OWNER TO postgres;

--
-- Name: studentinfo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentinfo (
    rollno integer NOT NULL,
    name character varying(50) NOT NULL,
    leavesleft integer NOT NULL,
    CONSTRAINT leftleaves CHECK ((leavesleft >= 0))
);


ALTER TABLE public.studentinfo OWNER TO postgres;

--
-- Name: tainstructor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tainstructor (
    rollno integer NOT NULL,
    instructorname character varying(50) NOT NULL,
    course character varying(50)
);


ALTER TABLE public.tainstructor OWNER TO postgres;

--
-- Data for Name: faculty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faculty (name, email) FROM stdin;
\.
COPY public.faculty (name, email) FROM '$$PATH$$/2998.dat';

--
-- Data for Name: holidays; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.holidays (holiday, date, day, type) FROM stdin;
\.
COPY public.holidays (holiday, date, day, type) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: leaveapplications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leaveapplications (rollno, nameofscholar, department, program, leavesleft, typeofleave, leavepurpose, daysapplied, fromdate, todate, natureofduty, alternatestudrolno, alternatestudname, fa_approval, mentor_approval, admin_approval) FROM stdin;
\.
COPY public.leaveapplications (rollno, nameofscholar, department, program, leavesleft, typeofleave, leavepurpose, daysapplied, fromdate, todate, natureofduty, alternatestudrolno, alternatestudname, fa_approval, mentor_approval, admin_approval) FROM '$$PATH$$/2997.dat';

--
-- Data for Name: studentfaculty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentfaculty (rollno, name, facultyadvisor, projectmentor) FROM stdin;
\.
COPY public.studentfaculty (rollno, name, facultyadvisor, projectmentor) FROM '$$PATH$$/2995.dat';

--
-- Data for Name: studentinfo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentinfo (rollno, name, leavesleft) FROM stdin;
\.
COPY public.studentinfo (rollno, name, leavesleft) FROM '$$PATH$$/2994.dat';

--
-- Data for Name: tainstructor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tainstructor (rollno, instructorname, course) FROM stdin;
\.
COPY public.tainstructor (rollno, instructorname, course) FROM '$$PATH$$/2996.dat';

--
-- Name: leaveapplications leaveapplications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaveapplications
    ADD CONSTRAINT leaveapplications_pkey PRIMARY KEY (rollno);


--
-- Name: studentfaculty studentfaculty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentfaculty
    ADD CONSTRAINT studentfaculty_pkey PRIMARY KEY (rollno);


--
-- Name: studentinfo studentinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentinfo
    ADD CONSTRAINT studentinfo_pkey PRIMARY KEY (rollno);


--
-- Name: tainstructor tainstructor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tainstructor
    ADD CONSTRAINT tainstructor_pkey PRIMARY KEY (rollno);


--
-- PostgreSQL database dump complete
--

